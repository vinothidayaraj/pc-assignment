import { Component, OnInit, Input } from '@angular/core';
import { ListDataService } from '../services/listdata.services';

@Component({
  selector: 'app-details-module',
  templateUrl: './details-module.component.html',
  styleUrls: ['./details-module.component.css'],
  providers: [ListDataService]
})
export class DetailsModuleComponent implements OnInit {
  detailList: string[] = [];
  @Input() detListId:any;
  itemList:string[] = [];
  dataSource:any = [];
  detailsContainer = document.getElementById('detailsContainer')!;
  constructor(private listData: ListDataService) { }

  ngOnInit(): void {
  }

  ngOnChanges(changes:any) {
    this.detListId=changes.detListId.currentValue;
    this.getDetailsList(this.detListId);
  }

  getDetailsList(detListId:any){
    this.listData.detail(detListId).subscribe((data) => {
      data.forEach((element) => {
        this.detailList = element.detailsArr;
      });
    });
  }

}

import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable()
export class ListDataService {
  responseData:any;
  list(): Observable<any[]> {
    return of([
        {listId:1, listDate: null, listName: "Competitive Intelligence", entityCount: 0},
        {listId:2, listDate: null, listName: "My Vendors", entityCount: 0},
        {listId:3, listDate: null, listName: "My Customers", entityCount: 0},
        {listId:4, listDate: "Jul 23", listName: "Test_30_results", entityCount: 28},
        {listId:5, listDate: "Jun 28", listName: "To_index", entityCount: 100},
        {listId:6, listDate: "Apr 10", listName: "KPMG Requested Companies - Listed Set_Prasada Kumar", entityCount: 34},
        {listId:7, listDate: "Mar 12", listName: "Error case-LTB to EBITDA Blank_Prasada Kumar", entityCount: 24},
        {listId:8, listDate: "Dec 14", listName: "Two Companies", entityCount: 2},
        {listId:9, listDate: "Nov 01", listName: "Custom", entityCount: 30},
        {listId:10, listDate: "Oct 29", listName: "Mumbai", entityCount: 3},
        {listId:11, listDate: "Sep 10", listName: "Bangalore", entityCount: 10}
    ]);
  }


  detail(lstId:number): Observable<any[]> {
    this.responseData = detailsList.find((x:any) => x.listId === lstId)
    return of([
      this.responseData
    ]);
  }
}

const detailsList: any = [
  {listId: 1, detailsArr: ['Bundi technologies Pvt Ltd', 'Hector Beverages Pvt Ltd', 'Puma Sports']},
  {listId: 2, detailsArr: ['Dewan housing', 'Infosys Ltd', 'Delhivery']},
  {listId: 3, detailsArr: ['Wow momo Pvt Ltd', 'Puma Sports', 'Rebel food Pvt Ltd']},
  {listId: 4, detailsArr: ['Balaji wafers Pvt Ltd', 'Vodafone Idea Ltd', 'Vakrangee Ltd']},
  {listId: 5, detailsArr: ['Bundi technologies Pvt Ltd', 'Hector Beverages Pvt Ltd', 'Puma Sports']},
  {listId: 6, detailsArr: ['Dewan housing', 'Infosys Ltd', 'Delhivery']},
  {listId: 7, detailsArr: ['Wow momo Pvt Ltd', 'Puma Sports', 'Rebel food Pvt Ltd']},
  {listId: 8, detailsArr: ['Balaji wafers Pvt Ltd', 'Vodafone Idea Ltd', 'Vakrangee Ltd']},
  {listId: 9, detailsArr: ['Bundi technologies Pvt Ltd', 'Hector Beverages Pvt Ltd', 'Puma Sports']},
  {listId: 10, detailsArr: ['Dewan housing', 'Infosys Ltd', 'Delhivery']},
  {listId: 11, detailsArr: ['Wow momo Pvt Ltd', 'Puma Sports', 'Rebel food Pvt Ltd']}
];
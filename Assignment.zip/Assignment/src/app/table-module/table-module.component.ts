import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ListDataService } from '../services/listdata.services';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-table-module',
  templateUrl: './table-module.component.html',
  styleUrls: ['./table-module.component.css'],
  providers: [ListDataService]
})
export class TableModuleComponent implements OnInit {
  displayedColumns: string[] = ['listDate', 'listName', 'entityCount', 'actions', 'details'];
  itemList: ListElement[] = [];
  dataSource:any = [];

  constructor(private listData: ListDataService) { }
  @Input() filterValue: String ='';
  @Output() getResponse:EventEmitter<any> = new EventEmitter<any>();

  ngOnInit(): void {
    this.itemList = [];
    this.listData.list().subscribe((data) => {
      data.forEach((element) => {
        this.itemList.push({
          listId: element.listId,
          listDate: element.listDate,
          listName: element.listName,
          entityCount: element.entityCount
        });
      });
      this.dataSource = new MatTableDataSource(this.itemList);
    });
  }

  ngOnChanges(changes:any) {
    this.filterList(changes.filterValue.currentValue);
  }

  filterList(filValue:any){
    this.dataSource .filter = filValue.trim().toLowerCase();
  }

  getListDetails(listId:number){
    this.getResponse.emit(listId);
  }

}

export class ListElement {
  listId!: Number;
  listDate!: Date | null;
  listName!: String;
  entityCount!: Number;
}
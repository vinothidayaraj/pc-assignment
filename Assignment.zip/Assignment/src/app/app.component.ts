import { Component, OnInit } from '@angular/core';
import { ListDataService } from './services/listdata.services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ListDataService]
})

export class AppComponent implements OnInit {
  filterInput: String='';
  detListId:any;
  ngOnInit():void{
    
  }
  constructor(private listData: ListDataService) {}
  applyFilter(event: Event) {
    this.filterInput = (event.target as HTMLInputElement).value;
  }

  getDetails(listId:any){
    this.detListId = listId;
  }
}

export class ListElement {
  listId!: Number;
  listDate!: Date | null;
  listName!: String;
  entityCount!: Number;
}